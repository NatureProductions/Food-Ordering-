
package futis;

public class Menus extends Customer {
public void townMenu(){
    System.out.println("\n SELECT YOUR NEAREST TOWN");
    System.out.println("1. Mbabane");
    System.out.println("2. Nhlangano");
    System.out.println("3. Hlatikhulu");
    System.out.println("4. Mahlanya");
    System.out.println("5. Manzini");
    System.out.println("6. Siteki");
    System.out.println("7. Simunye");
    System.out.println("8. Big Bend");
    System.out.println("9. Pigg's Peak");
    System.out.println("10. Matsapa"); 
}
public void subTownsMenu(){
    System.out.println("\n SELECT YOUR SUBTOWN");
    System.out.println("1. Zone 1");
    System.out.println("2. Zone 2");
    System.out.println("3. Sandla");
    System.out.println("4. Sdvashini");
    System.out.println("5. Mbangweni");
    System.out.println("6. Woodlands");
    System.out.println("7. Thembelisha");
    System.out.println("8. Skom");
    System.out.println("9. Mangwaneni");
    System.out.println("10. Around Town");
}
public void Food(){
    System.out.println("MAKE YOUR ORDER FROM THE LIST BELLOW");
    System.out.println("1. 2 Pieces = E45");
    System.out.println("2. Chips = E20");
    System.out.println("3. Burger = E50");
    System.out.println("4. Drink = E30");
}
public void peymentmethods(){
    System.out.println("SELECT PAYMENT METHOD");
    System.out.println("1. Credit Card");
    System.out.println("2. eWallet");
    System.out.println("3. MOMO");
    System.out.println("4. eMali");
    
}
public void thanks(){
     System.out.println("THANK YOU FOR GIVING US YOUR INFOMATION, \nTHIS WILL MAKE THINGS EASY FOR YOUR DILIVERY \n");
}
    
}
