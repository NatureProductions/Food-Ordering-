package futis;

public class Buysell extends Futis {

   
public void Product(){
    
    System.out.println("\n p_id:  " + p_id);
    System.out.println("p_name:  " + p_name);
    System.out.println("p_price:  " + p_price);
    System.out.println("Describtion:  "+ p_describtion);
    System.out.println("Supply Date:  "+ now);
    System.out.println("Sup_id:  "+ sup_id);
    System.out.println("Emp_id:  "+ emp_id);
}
        
    
    
    
}
