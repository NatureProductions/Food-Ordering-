package futis;
public class Stuff extends Futis{
 String emp_name, emp_lastname;
 String gender;
 int emp_contact, emp_age;
 
 
public void employee(){
    System.out.println("entra");
    emp_id = cin.nextInt();
    if(emp_id == 123){
        emp_id = 123;
        emp_name = "simiso";
        
    }
        
    
}
    
}
